-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: michelada
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comanda_items`
--

DROP TABLE IF EXISTS `comanda_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comanda_items` (
  `id` char(36) NOT NULL,
  `comanda_id` char(36) NOT NULL,
  `producto_id` varchar(50) NOT NULL,
  `producto_nombre` varchar(120) NOT NULL,
  `tamano` varchar(50) DEFAULT NULL,
  `precio_base` decimal(10,2) NOT NULL,
  `toppings_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`toppings_json`)),
  `adiciones_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`adiciones_json`)),
  `notas` varchar(500) DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `orden` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_items_comanda` (`comanda_id`),
  CONSTRAINT `fk_items_comanda` FOREIGN KEY (`comanda_id`) REFERENCES `comandas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comanda_items`
--

LOCK TABLES `comanda_items` WRITE;
/*!40000 ALTER TABLE `comanda_items` DISABLE KEYS */;
INSERT INTO `comanda_items` VALUES ('2e81e01f-7daa-4a1d-ac65-0545c3cb20e4','f60dec97-e168-4c88-b44b-6bebb018c5ef','frutos_rojos_ginger','Frutos Rojos · Ginger',NULL,14000.00,'[]','[{\"id\": \"gomitas\", \"name\": \"Gomitas enchiladas\", \"price\": 4000.0}, {\"id\": \"rielitos\", \"name\": \"Rielitos\", \"price\": 5000.0}]',NULL,23000.00,0),('37f1e129-a482-46df-9729-ac0af304b19c','8bc06dde-0771-45a2-952f-ccca1ec3c262','lulo_cerveza','Lulo · Cerveza',NULL,15000.00,'[]','[]',NULL,15000.00,0),('5e608266-c7bc-4cf4-b114-4dd26e690b61','4c7cb601-6854-43f3-9fb7-637382e57c2a','lulo_soda','Lulo · Soda',NULL,14000.00,'[]','[{\"id\": \"pepino\", \"name\": \"Pepino\", \"price\": 10.0}]',NULL,14010.00,0),('a869b2bc-7ad6-4aae-ae72-cde7126be68b','71adb263-63a6-4162-b9e5-2ae42ca70085','tradicional_ginger','Tradicional · Ginger',NULL,10000.00,'[]','[]',NULL,10000.00,0),('ad8f0ec9-4157-4bfd-b1fa-3b96188fae3b','f7b41dd0-faf5-4600-8bce-eda9e39122e7','sandia_cerveza','Sandía · Cerveza',NULL,15000.00,'[]','[{\"id\": \"gomitas\", \"name\": \"Gomitas enchiladas\", \"price\": 15.0}, {\"id\": \"rielitos\", \"name\": \"Rielitos\", \"price\": 20.0}]',NULL,15035.00,1),('fd0de3e9-11c0-4c04-b065-8ffb503f2415','f7b41dd0-faf5-4600-8bce-eda9e39122e7','manzana_verde_ginger','Manzana Verde · Ginger',NULL,14000.00,'[]','[{\"id\": \"camaron\", \"name\": \"Camar\\u00f3n cocido\", \"price\": 25.0}, {\"id\": \"pulpo\", \"name\": \"Pulpo\", \"price\": 35.0}, {\"id\": \"pepino\", \"name\": \"Pepino\", \"price\": 10.0}]',NULL,14070.00,0);
/*!40000 ALTER TABLE `comanda_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comandas`
--

DROP TABLE IF EXISTS `comandas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comandas` (
  `id` char(36) NOT NULL,
  `folio` int(10) unsigned NOT NULL,
  `orden_cola` int(10) unsigned NOT NULL DEFAULT 1,
  `cliente` varchar(100) NOT NULL,
  `mesa_id` varchar(50) DEFAULT NULL,
  `mesa_nombre` varchar(100) DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` enum('pendiente','lista','entregada') NOT NULL DEFAULT 'pendiente',
  `mesero_id` int(10) unsigned DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_comandas_folio` (`folio`),
  KEY `idx_comandas_status` (`status`),
  KEY `idx_comandas_mesa` (`mesa_id`),
  KEY `idx_comandas_creado` (`creado_en`),
  KEY `fk_comandas_mesero` (`mesero_id`),
  KEY `idx_comandas_orden_dia` (`creado_en`,`orden_cola`),
  CONSTRAINT `fk_comandas_mesa` FOREIGN KEY (`mesa_id`) REFERENCES `mesas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_comandas_mesero` FOREIGN KEY (`mesero_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comandas`
--

LOCK TABLES `comandas` WRITE;
/*!40000 ALTER TABLE `comandas` DISABLE KEYS */;
INSERT INTO `comandas` VALUES ('4c7cb601-6854-43f3-9fb7-637382e57c2a',1004,4,'yyyy','m4','Mesa 4',14010.00,'entregada',2,'2026-06-05 03:19:48','2026-06-05 18:37:33'),('71adb263-63a6-4162-b9e5-2ae42ca70085',1001,1,'maria','m1','Mesa 1',10000.00,'entregada',2,'2026-06-05 03:08:05','2026-06-05 18:37:20'),('8bc06dde-0771-45a2-952f-ccca1ec3c262',1002,2,'juan','m2','Mesa 2',15000.00,'entregada',2,'2026-06-05 03:09:14','2026-06-05 18:37:29'),('f60dec97-e168-4c88-b44b-6bebb018c5ef',1005,1,'Juanca','m5','Mesa 5',23000.00,'entregada',2,'2026-06-05 18:34:34','2026-06-05 18:37:36'),('f7b41dd0-faf5-4600-8bce-eda9e39122e7',1003,3,'jose','m3','Mesa 3',29105.00,'entregada',2,'2026-06-05 03:11:22','2026-06-05 18:37:27');
/*!40000 ALTER TABLE `comandas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario`
--

DROP TABLE IF EXISTS `inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventario` (
  `clave` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `stock` decimal(12,3) NOT NULL DEFAULT 0.000,
  `stock_inicial` decimal(12,3) NOT NULL DEFAULT 0.000,
  `unidad` varchar(20) NOT NULL DEFAULT 'pz',
  `minimo` decimal(12,3) NOT NULL DEFAULT 5.000,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario`
--

LOCK TABLES `inventario` WRITE;
/*!40000 ALTER TABLE `inventario` DISABLE KEYS */;
INSERT INTO `inventario` VALUES ('cacahuate','Cacahuates',2000.000,2000.000,'g',300.000),('camaron','Camarón cocido',40.000,40.000,'pz',5.000),('cerveza','Cerveza (botellas)',95.000,96.000,'pz',10.000),('chamoy','Chamoy',3.000,3.000,'L',1.000),('clamato','Clamato',8.000,8.000,'L',2.000),('cola_pola','Cola y pola',48.000,48.000,'pz',12.000),('ginger','Ginger ale',48.000,48.000,'pz',12.000),('gomitas','Gomitas enchiladas',1460.000,1500.000,'g',200.000),('jicama','Jícama',15.000,15.000,'pz',5.000),('limon','Limón',100.000,100.000,'pz',15.000),('pepino','Pepino',25.000,25.000,'pz',5.000),('pulpo','Pulpo',20.000,20.000,'pz',5.000),('rielitos','Rielitos',59.000,60.000,'pz',10.000),('smirnoff','Smirnoff',24.000,24.000,'pz',6.000),('soda','Soda',48.000,48.000,'pz',12.000),('tajin','Tajín',1500.000,1500.000,'g',200.000);
/*!40000 ALTER TABLE `inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_adiciones`
--

DROP TABLE IF EXISTS `menu_adiciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_adiciones` (
  `id` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock_key` varchar(50) DEFAULT NULL,
  `cantidad` decimal(10,3) NOT NULL DEFAULT 1.000,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `orden` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_adiciones`
--

LOCK TABLES `menu_adiciones` WRITE;
/*!40000 ALTER TABLE `menu_adiciones` DISABLE KEYS */;
INSERT INTO `menu_adiciones` VALUES ('cacahuate','Cacahuates',4000.00,'cacahuate',50.000,1,5),('camaron','Camarón cocido',5000.00,'camaron',2.000,1,1),('gomitas','Gomitas enchiladas',4000.00,'gomitas',40.000,1,6),('jicama','Jícama',3000.00,'jicama',1.000,1,4),('pepino','Pepino',3000.00,'pepino',1.000,1,3),('pulpo','Pulpo',8000.00,'pulpo',2.000,1,2),('rielitos','Rielitos',5000.00,'rielitos',1.000,1,7);
/*!40000 ALTER TABLE `menu_adiciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_categorias`
--

DROP TABLE IF EXISTS `menu_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_categorias` (
  `id` varchar(50) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `descripcion` varchar(300) NOT NULL DEFAULT '',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `orden` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_categorias`
--

LOCK TABLES `menu_categorias` WRITE;
/*!40000 ALTER TABLE `menu_categorias` DISABLE KEYS */;
INSERT INTO `menu_categorias` VALUES ('blueberry_mango','Blueberry Mango','',1,12),('bombom_cereza','Bombom Cereza','Cereza',1,2),('especiales','Especiales','Micheladas premium',1,13),('frutos_rojos','Frutos Rojos','Cereza + sandía + fresa',1,7),('lulo','Lulo','',1,3),('mango_biche','Mango Biche','',1,8),('manzana_verde','Manzana Verde','',1,6),('maracubombom','Maracubombom','Maracuyá + cereza',1,11),('maracumazana','Maracumanzana','Maracuyá + manzana',1,4),('maragumango','Maragumango','Mango + maracuyá',1,5),('micheladas','Micheladas','Nuestras micheladas preparadas al momento',1,1),('sandia','Sandía','',1,9),('tamarindo_mango','Tamarindo Mango','',1,10),('tradicional','Tradicional','Sal + limón',1,1);
/*!40000 ALTER TABLE `menu_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_fase_opciones`
--

DROP TABLE IF EXISTS `menu_fase_opciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_fase_opciones` (
  `id` varchar(50) NOT NULL,
  `fase_id` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `inventario_clave` varchar(50) DEFAULT NULL,
  `cantidad` decimal(10,3) NOT NULL DEFAULT 1.000,
  PRIMARY KEY (`id`),
  KEY `fk_fo_fase` (`fase_id`),
  CONSTRAINT `fk_fo_fase` FOREIGN KEY (`fase_id`) REFERENCES `menu_fases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_fase_opciones`
--

LOCK TABLES `menu_fase_opciones` WRITE;
/*!40000 ALTER TABLE `menu_fase_opciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_fase_opciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_fases`
--

DROP TABLE IF EXISTS `menu_fases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_fases` (
  `id` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(300) NOT NULL DEFAULT '',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `orden` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_fases`
--

LOCK TABLES `menu_fases` WRITE;
/*!40000 ALTER TABLE `menu_fases` DISABLE KEYS */;
INSERT INTO `menu_fases` VALUES ('nectar','Néctar','Jarabes y néctares',1,2),('topping','Topping','Extras y condimentos',1,1);
/*!40000 ALTER TABLE `menu_fases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_producto_fase_opcion`
--

DROP TABLE IF EXISTS `menu_producto_fase_opcion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_producto_fase_opcion` (
  `producto_id` varchar(50) NOT NULL,
  `opcion_id` varchar(50) NOT NULL,
  PRIMARY KEY (`producto_id`,`opcion_id`),
  KEY `fk_pfo_opcion` (`opcion_id`),
  CONSTRAINT `fk_pfo_opcion` FOREIGN KEY (`opcion_id`) REFERENCES `menu_fase_opciones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pfo_producto` FOREIGN KEY (`producto_id`) REFERENCES `menu_productos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_producto_fase_opcion`
--

LOCK TABLES `menu_producto_fase_opcion` WRITE;
/*!40000 ALTER TABLE `menu_producto_fase_opcion` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_producto_fase_opcion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_producto_topping`
--

DROP TABLE IF EXISTS `menu_producto_topping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_producto_topping` (
  `producto_id` varchar(50) NOT NULL,
  `topping_id` varchar(50) NOT NULL,
  PRIMARY KEY (`producto_id`,`topping_id`),
  KEY `fk_pt_topping` (`topping_id`),
  CONSTRAINT `fk_pt_producto` FOREIGN KEY (`producto_id`) REFERENCES `menu_productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pt_topping` FOREIGN KEY (`topping_id`) REFERENCES `menu_toppings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_producto_topping`
--

LOCK TABLES `menu_producto_topping` WRITE;
/*!40000 ALTER TABLE `menu_producto_topping` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_producto_topping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_productos`
--

DROP TABLE IF EXISTS `menu_productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_productos` (
  `id` varchar(50) NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `descripcion` varchar(500) NOT NULL DEFAULT '',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `orden` int(11) NOT NULL DEFAULT 0,
  `pasos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`pasos`)),
  `categoria_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_productos`
--

LOCK TABLES `menu_productos` WRITE;
/*!40000 ALTER TABLE `menu_productos` DISABLE KEYS */;
INSERT INTO `menu_productos` VALUES ('blueberry_mango_cerveza','Blueberry Mango · Cerveza',15000.00,'Blueberry Mango',1,3,'[\"notas\"]','blueberry_mango'),('blueberry_mango_cola_pola','Blueberry Mango · Cola y pola',15000.00,'Blueberry Mango',1,4,'[\"notas\"]','blueberry_mango'),('blueberry_mango_ginger','Blueberry Mango · Ginger',14000.00,'Blueberry Mango',1,1,'[\"notas\"]','blueberry_mango'),('blueberry_mango_smirnoff','Blueberry Mango · Smirnoff',23000.00,'Blueberry Mango',1,5,'[\"notas\"]','blueberry_mango'),('blueberry_mango_soda','Blueberry Mango · Soda',14000.00,'Blueberry Mango',1,2,'[\"notas\"]','blueberry_mango'),('bombom_cereza_cerveza','Bombom Cereza · Cerveza',15000.00,'Cereza',1,3,'[\"notas\"]','bombom_cereza'),('bombom_cereza_cola_pola','Bombom Cereza · Cola y pola',15000.00,'Cereza',1,4,'[\"notas\"]','bombom_cereza'),('bombom_cereza_ginger','Bombom Cereza · Ginger',14000.00,'Cereza',1,1,'[\"notas\"]','bombom_cereza'),('bombom_cereza_smirnoff','Bombom Cereza · Smirnoff',23000.00,'Cereza',1,5,'[\"notas\"]','bombom_cereza'),('bombom_cereza_soda','Bombom Cereza · Soda',14000.00,'Cereza',1,2,'[\"notas\"]','bombom_cereza'),('diablo_rojo','Diablo Rojo',25000.00,'Fresa + cereza + sandía, curaçao, ají, tajín, Corona',1,2,'[\"notas\"]','especiales'),('endiablada','Endiablada',25000.00,'Mango + maracuyá, curaçao, ají, tajín, Corona',1,1,'[\"notas\"]','especiales'),('frutos_rojos_cerveza','Frutos Rojos · Cerveza',15000.00,'Cereza + sandía + fresa',1,3,'[\"notas\"]','frutos_rojos'),('frutos_rojos_cola_pola','Frutos Rojos · Cola y pola',15000.00,'Cereza + sandía + fresa',1,4,'[\"notas\"]','frutos_rojos'),('frutos_rojos_ginger','Frutos Rojos · Ginger',14000.00,'Cereza + sandía + fresa',1,1,'[\"notas\"]','frutos_rojos'),('frutos_rojos_smirnoff','Frutos Rojos · Smirnoff',23000.00,'Cereza + sandía + fresa',1,5,'[\"notas\"]','frutos_rojos'),('frutos_rojos_soda','Frutos Rojos · Soda',14000.00,'Cereza + sandía + fresa',1,2,'[\"notas\"]','frutos_rojos'),('lulo_cerveza','Lulo · Cerveza',15000.00,'Lulo',1,3,'[\"notas\"]','lulo'),('lulo_cola_pola','Lulo · Cola y pola',15000.00,'Lulo',1,4,'[\"notas\"]','lulo'),('lulo_ginger','Lulo · Ginger',14000.00,'Lulo',1,1,'[\"notas\"]','lulo'),('lulo_smirnoff','Lulo · Smirnoff',23000.00,'Lulo',1,5,'[\"notas\"]','lulo'),('lulo_soda','Lulo · Soda',14000.00,'Lulo',1,2,'[\"notas\"]','lulo'),('mango_biche_cerveza','Mango Biche · Cerveza',15000.00,'Mango Biche',1,3,'[\"notas\"]','mango_biche'),('mango_biche_cola_pola','Mango Biche · Cola y pola',15000.00,'Mango Biche',1,4,'[\"notas\"]','mango_biche'),('mango_biche_ginger','Mango Biche · Ginger',14000.00,'Mango Biche',1,1,'[\"notas\"]','mango_biche'),('mango_biche_smirnoff','Mango Biche · Smirnoff',23000.00,'Mango Biche',1,5,'[\"notas\"]','mango_biche'),('mango_biche_soda','Mango Biche · Soda',14000.00,'Mango Biche',1,2,'[\"notas\"]','mango_biche'),('manzana_verde_cerveza','Manzana Verde · Cerveza',15000.00,'Manzana Verde',1,3,'[\"notas\"]','manzana_verde'),('manzana_verde_cola_pola','Manzana Verde · Cola y pola',15000.00,'Manzana Verde',1,4,'[\"notas\"]','manzana_verde'),('manzana_verde_ginger','Manzana Verde · Ginger',14000.00,'Manzana Verde',1,1,'[\"notas\"]','manzana_verde'),('manzana_verde_smirnoff','Manzana Verde · Smirnoff',23000.00,'Manzana Verde',1,5,'[\"notas\"]','manzana_verde'),('manzana_verde_soda','Manzana Verde · Soda',14000.00,'Manzana Verde',1,2,'[\"notas\"]','manzana_verde'),('maracubombom_cerveza','Maracubombom · Cerveza',15000.00,'Maracuyá + cereza',1,3,'[\"notas\"]','maracubombom'),('maracubombom_cola_pola','Maracubombom · Cola y pola',15000.00,'Maracuyá + cereza',1,4,'[\"notas\"]','maracubombom'),('maracubombom_ginger','Maracubombom · Ginger',14000.00,'Maracuyá + cereza',1,1,'[\"notas\"]','maracubombom'),('maracubombom_smirnoff','Maracubombom · Smirnoff',23000.00,'Maracuyá + cereza',1,5,'[\"notas\"]','maracubombom'),('maracubombom_soda','Maracubombom · Soda',14000.00,'Maracuyá + cereza',1,2,'[\"notas\"]','maracubombom'),('maracumazana_cerveza','Maracumanzana · Cerveza',15000.00,'Maracuyá + manzana',1,3,'[\"notas\"]','maracumazana'),('maracumazana_cola_pola','Maracumanzana · Cola y pola',15000.00,'Maracuyá + manzana',1,4,'[\"notas\"]','maracumazana'),('maracumazana_ginger','Maracumanzana · Ginger',14000.00,'Maracuyá + manzana',1,1,'[\"notas\"]','maracumazana'),('maracumazana_smirnoff','Maracumanzana · Smirnoff',23000.00,'Maracuyá + manzana',1,5,'[\"notas\"]','maracumazana'),('maracumazana_soda','Maracumanzana · Soda',14000.00,'Maracuyá + manzana',1,2,'[\"notas\"]','maracumazana'),('maragumango_cerveza','Maragumango · Cerveza',15000.00,'Mango + maracuyá',1,3,'[\"notas\"]','maragumango'),('maragumango_cola_pola','Maragumango · Cola y pola',15000.00,'Mango + maracuyá',1,4,'[\"notas\"]','maragumango'),('maragumango_ginger','Maragumango · Ginger',14000.00,'Mango + maracuyá',1,1,'[\"notas\"]','maragumango'),('maragumango_smirnoff','Maragumango · Smirnoff',23000.00,'Mango + maracuyá',1,5,'[\"notas\"]','maragumango'),('maragumango_soda','Maragumango · Soda',14000.00,'Mango + maracuyá',1,2,'[\"notas\"]','maragumango'),('sandia_cerveza','Sandía · Cerveza',15000.00,'Sandía',1,3,'[\"notas\"]','sandia'),('sandia_cola_pola','Sandía · Cola y pola',15000.00,'Sandía',1,4,'[\"notas\"]','sandia'),('sandia_ginger','Sandía · Ginger',14000.00,'Sandía',1,1,'[\"notas\"]','sandia'),('sandia_smirnoff','Sandía · Smirnoff',23000.00,'Sandía',1,5,'[\"notas\"]','sandia'),('sandia_soda','Sandía · Soda',14000.00,'Sandía',1,2,'[\"notas\"]','sandia'),('tamarindo_mango_cerveza','Tamarindo Mango · Cerveza',15000.00,'Tamarindo Mango',1,3,'[\"notas\"]','tamarindo_mango'),('tamarindo_mango_cola_pola','Tamarindo Mango · Cola y pola',15000.00,'Tamarindo Mango',1,4,'[\"notas\"]','tamarindo_mango'),('tamarindo_mango_ginger','Tamarindo Mango · Ginger',14000.00,'Tamarindo Mango',1,1,'[\"notas\"]','tamarindo_mango'),('tamarindo_mango_smirnoff','Tamarindo Mango · Smirnoff',23000.00,'Tamarindo Mango',1,5,'[\"notas\"]','tamarindo_mango'),('tamarindo_mango_soda','Tamarindo Mango · Soda',14000.00,'Tamarindo Mango',1,2,'[\"notas\"]','tamarindo_mango'),('tradicional_cerveza','Tradicional · Cerveza',11000.00,'Sal + limón',1,3,'[\"notas\"]','tradicional'),('tradicional_cola_pola','Tradicional · Cola y pola',11000.00,'Sal + limón',1,4,'[\"notas\"]','tradicional'),('tradicional_ginger','Tradicional · Ginger',10000.00,'Sal + limón',1,1,'[\"notas\"]','tradicional'),('tradicional_smirnoff','Tradicional · Smirnoff',16000.00,'Sal + limón',1,5,'[\"notas\"]','tradicional'),('tradicional_soda','Tradicional · Soda',10000.00,'Sal + limón',1,2,'[\"notas\"]','tradicional');
/*!40000 ALTER TABLE `menu_productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_toppings`
--

DROP TABLE IF EXISTS `menu_toppings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_toppings` (
  `id` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_toppings`
--

LOCK TABLES `menu_toppings` WRITE;
/*!40000 ALTER TABLE `menu_toppings` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_toppings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mesas`
--

DROP TABLE IF EXISTS `mesas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mesas` (
  `id` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `capacidad` int(11) NOT NULL DEFAULT 4,
  `estado` enum('libre','ocupada','reservada') NOT NULL DEFAULT 'libre',
  `cliente` varchar(100) DEFAULT NULL,
  `orden` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mesas`
--

LOCK TABLES `mesas` WRITE;
/*!40000 ALTER TABLE `mesas` DISABLE KEYS */;
INSERT INTO `mesas` VALUES ('barra','Barra',8,'libre',NULL,6),('llevar','Para llevar',0,'libre',NULL,7),('m1','Mesa 1',4,'libre',NULL,1),('m2','Mesa 2',4,'libre',NULL,2),('m3','Mesa 3',2,'libre',NULL,3),('m4','Mesa 4',6,'libre',NULL,4),('m5','Mesa 5',4,'libre',NULL,5);
/*!40000 ALTER TABLE `mesas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nomina_config`
--

DROP TABLE IF EXISTS `nomina_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nomina_config` (
  `usuario_id` int(10) unsigned NOT NULL,
  `salario_base` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tipo_pago` enum('diario','semanal','quincenal','mensual') NOT NULL DEFAULT 'quincenal',
  `tarifa_hora_extra` decimal(10,2) DEFAULT NULL,
  `puesto` varchar(100) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`usuario_id`),
  CONSTRAINT `fk_nomina_config_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nomina_config`
--

LOCK TABLES `nomina_config` WRITE;
/*!40000 ALTER TABLE `nomina_config` DISABLE KEYS */;
INSERT INTO `nomina_config` VALUES (4,2000.00,'quincenal',NULL,NULL,1,'2026-06-13 06:42:07');
/*!40000 ALTER TABLE `nomina_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nomina_prestamo_abonos`
--

DROP TABLE IF EXISTS `nomina_prestamo_abonos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nomina_prestamo_abonos` (
  `id` char(36) NOT NULL,
  `prestamo_id` char(36) NOT NULL,
  `recibo_id` char(36) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_abono_recibo_prestamo` (`recibo_id`,`prestamo_id`),
  KEY `idx_abono_prestamo` (`prestamo_id`),
  CONSTRAINT `fk_abono_prestamo` FOREIGN KEY (`prestamo_id`) REFERENCES `nomina_prestamos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_abono_recibo` FOREIGN KEY (`recibo_id`) REFERENCES `nomina_recibos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nomina_prestamo_abonos`
--

LOCK TABLES `nomina_prestamo_abonos` WRITE;
/*!40000 ALTER TABLE `nomina_prestamo_abonos` DISABLE KEYS */;
INSERT INTO `nomina_prestamo_abonos` VALUES ('b16f59d6-2d34-472f-ac5a-44f4edc49536','4736d33d-1f76-4e36-861f-e01928ef1501','d9d8abf1-98de-49fa-a057-8e1399368f25',200.00,'2026-06-13 06:42:07');
/*!40000 ALTER TABLE `nomina_prestamo_abonos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nomina_prestamos`
--

DROP TABLE IF EXISTS `nomina_prestamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nomina_prestamos` (
  `id` char(36) NOT NULL,
  `usuario_id` int(10) unsigned NOT NULL,
  `concepto` varchar(200) NOT NULL,
  `monto_total` decimal(12,2) NOT NULL,
  `saldo_pendiente` decimal(12,2) NOT NULL,
  `cuota_periodo` decimal(10,2) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_prestamo_usuario` (`usuario_id`),
  KEY `idx_prestamo_activo` (`activo`),
  CONSTRAINT `fk_prestamo_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nomina_prestamos`
--

LOCK TABLES `nomina_prestamos` WRITE;
/*!40000 ALTER TABLE `nomina_prestamos` DISABLE KEYS */;
INSERT INTO `nomina_prestamos` VALUES ('4736d33d-1f76-4e36-861f-e01928ef1501',4,'Anticipo test',500.00,300.00,200.00,1,'2026-06-13 06:42:07');
/*!40000 ALTER TABLE `nomina_prestamos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nomina_recibos`
--

DROP TABLE IF EXISTS `nomina_recibos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nomina_recibos` (
  `id` char(36) NOT NULL,
  `usuario_id` int(10) unsigned NOT NULL,
  `anio` smallint(5) unsigned NOT NULL,
  `mes` tinyint(3) unsigned NOT NULL,
  `quincena` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `dias_trabajados` decimal(5,2) NOT NULL DEFAULT 0.00,
  `horas_extra` decimal(6,2) NOT NULL DEFAULT 0.00,
  `bonos` decimal(10,2) NOT NULL DEFAULT 0.00,
  `deducciones` decimal(10,2) NOT NULL DEFAULT 0.00,
  `descuento_prestamos` decimal(10,2) NOT NULL DEFAULT 0.00,
  `sueldo_bruto` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `notas` varchar(500) DEFAULT NULL,
  `estado` enum('borrador','pagado') NOT NULL DEFAULT 'borrador',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_nomina_periodo` (`usuario_id`,`anio`,`mes`,`quincena`),
  KEY `idx_nomina_periodo` (`anio`,`mes`,`quincena`),
  KEY `idx_nomina_estado` (`estado`),
  CONSTRAINT `fk_nomina_recibo_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nomina_recibos`
--

LOCK TABLES `nomina_recibos` WRITE;
/*!40000 ALTER TABLE `nomina_recibos` DISABLE KEYS */;
INSERT INTO `nomina_recibos` VALUES ('6bfb4e1b-d2af-40be-8463-4a004bcbaa0f',4,2026,6,1,15.00,2.00,100.00,50.00,0.00,3150.00,3100.00,NULL,'borrador','2026-06-13 06:42:07','2026-06-13 06:42:07'),('d9d8abf1-98de-49fa-a057-8e1399368f25',4,2027,3,1,15.00,0.00,0.00,0.00,200.00,2000.00,1800.00,NULL,'pagado','2026-06-13 06:42:07','2026-06-13 06:42:07');
/*!40000 ALTER TABLE `nomina_recibos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto_consumo`
--

DROP TABLE IF EXISTS `producto_consumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `producto_consumo` (
  `producto_id` varchar(50) NOT NULL,
  `inventario_clave` varchar(50) NOT NULL,
  `cantidad` decimal(12,3) NOT NULL,
  PRIMARY KEY (`producto_id`,`inventario_clave`),
  KEY `fk_pc_inventario` (`inventario_clave`),
  CONSTRAINT `fk_pc_inventario` FOREIGN KEY (`inventario_clave`) REFERENCES `inventario` (`clave`) ON DELETE CASCADE,
  CONSTRAINT `fk_pc_producto` FOREIGN KEY (`producto_id`) REFERENCES `menu_productos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto_consumo`
--

LOCK TABLES `producto_consumo` WRITE;
/*!40000 ALTER TABLE `producto_consumo` DISABLE KEYS */;
INSERT INTO `producto_consumo` VALUES ('blueberry_mango_cerveza','cerveza',1.000),('blueberry_mango_cerveza','limon',2.000),('blueberry_mango_cola_pola','cola_pola',1.000),('blueberry_mango_cola_pola','limon',2.000),('blueberry_mango_ginger','ginger',1.000),('blueberry_mango_ginger','limon',2.000),('blueberry_mango_smirnoff','limon',2.000),('blueberry_mango_smirnoff','smirnoff',1.000),('blueberry_mango_soda','limon',2.000),('blueberry_mango_soda','soda',1.000),('bombom_cereza_cerveza','cerveza',1.000),('bombom_cereza_cerveza','limon',2.000),('bombom_cereza_cola_pola','cola_pola',1.000),('bombom_cereza_cola_pola','limon',2.000),('bombom_cereza_ginger','ginger',1.000),('bombom_cereza_ginger','limon',2.000),('bombom_cereza_smirnoff','limon',2.000),('bombom_cereza_smirnoff','smirnoff',1.000),('bombom_cereza_soda','limon',2.000),('bombom_cereza_soda','soda',1.000),('diablo_rojo','cerveza',1.000),('diablo_rojo','limon',2.000),('endiablada','cerveza',1.000),('endiablada','limon',2.000),('frutos_rojos_cerveza','cerveza',1.000),('frutos_rojos_cerveza','limon',2.000),('frutos_rojos_cola_pola','cola_pola',1.000),('frutos_rojos_cola_pola','limon',2.000),('frutos_rojos_ginger','ginger',1.000),('frutos_rojos_ginger','limon',2.000),('frutos_rojos_smirnoff','limon',2.000),('frutos_rojos_smirnoff','smirnoff',1.000),('frutos_rojos_soda','limon',2.000),('frutos_rojos_soda','soda',1.000),('lulo_cerveza','cerveza',1.000),('lulo_cerveza','limon',2.000),('lulo_cola_pola','cola_pola',1.000),('lulo_cola_pola','limon',2.000),('lulo_ginger','ginger',1.000),('lulo_ginger','limon',2.000),('lulo_smirnoff','limon',2.000),('lulo_smirnoff','smirnoff',1.000),('lulo_soda','limon',2.000),('lulo_soda','soda',1.000),('mango_biche_cerveza','cerveza',1.000),('mango_biche_cerveza','limon',2.000),('mango_biche_cola_pola','cola_pola',1.000),('mango_biche_cola_pola','limon',2.000),('mango_biche_ginger','ginger',1.000),('mango_biche_ginger','limon',2.000),('mango_biche_smirnoff','limon',2.000),('mango_biche_smirnoff','smirnoff',1.000),('mango_biche_soda','limon',2.000),('mango_biche_soda','soda',1.000),('manzana_verde_cerveza','cerveza',1.000),('manzana_verde_cerveza','limon',2.000),('manzana_verde_cola_pola','cola_pola',1.000),('manzana_verde_cola_pola','limon',2.000),('manzana_verde_ginger','ginger',1.000),('manzana_verde_ginger','limon',2.000),('manzana_verde_smirnoff','limon',2.000),('manzana_verde_smirnoff','smirnoff',1.000),('manzana_verde_soda','limon',2.000),('manzana_verde_soda','soda',1.000),('maracubombom_cerveza','cerveza',1.000),('maracubombom_cerveza','limon',2.000),('maracubombom_cola_pola','cola_pola',1.000),('maracubombom_cola_pola','limon',2.000),('maracubombom_ginger','ginger',1.000),('maracubombom_ginger','limon',2.000),('maracubombom_smirnoff','limon',2.000),('maracubombom_smirnoff','smirnoff',1.000),('maracubombom_soda','limon',2.000),('maracubombom_soda','soda',1.000),('maracumazana_cerveza','cerveza',1.000),('maracumazana_cerveza','limon',2.000),('maracumazana_cola_pola','cola_pola',1.000),('maracumazana_cola_pola','limon',2.000),('maracumazana_ginger','ginger',1.000),('maracumazana_ginger','limon',2.000),('maracumazana_smirnoff','limon',2.000),('maracumazana_smirnoff','smirnoff',1.000),('maracumazana_soda','limon',2.000),('maracumazana_soda','soda',1.000),('maragumango_cerveza','cerveza',1.000),('maragumango_cerveza','limon',2.000),('maragumango_cola_pola','cola_pola',1.000),('maragumango_cola_pola','limon',2.000),('maragumango_ginger','ginger',1.000),('maragumango_ginger','limon',2.000),('maragumango_smirnoff','limon',2.000),('maragumango_smirnoff','smirnoff',1.000),('maragumango_soda','limon',2.000),('maragumango_soda','soda',1.000),('sandia_cerveza','cerveza',1.000),('sandia_cerveza','limon',2.000),('sandia_cola_pola','cola_pola',1.000),('sandia_cola_pola','limon',2.000),('sandia_ginger','ginger',1.000),('sandia_ginger','limon',2.000),('sandia_smirnoff','limon',2.000),('sandia_smirnoff','smirnoff',1.000),('sandia_soda','limon',2.000),('sandia_soda','soda',1.000),('tamarindo_mango_cerveza','cerveza',1.000),('tamarindo_mango_cerveza','limon',2.000),('tamarindo_mango_cola_pola','cola_pola',1.000),('tamarindo_mango_cola_pola','limon',2.000),('tamarindo_mango_ginger','ginger',1.000),('tamarindo_mango_ginger','limon',2.000),('tamarindo_mango_smirnoff','limon',2.000),('tamarindo_mango_smirnoff','smirnoff',1.000),('tamarindo_mango_soda','limon',2.000),('tamarindo_mango_soda','soda',1.000),('tradicional_cerveza','cerveza',1.000),('tradicional_cerveza','limon',2.000),('tradicional_cola_pola','cola_pola',1.000),('tradicional_cola_pola','limon',2.000),('tradicional_ginger','ginger',1.000),('tradicional_ginger','limon',2.000),('tradicional_smirnoff','limon',2.000),('tradicional_smirnoff','smirnoff',1.000),('tradicional_soda','limon',2.000),('tradicional_soda','soda',1.000);
/*!40000 ALTER TABLE `producto_consumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `rol` enum('admin','mesero','cocinero') NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_usuarios_email` (`email`),
  KEY `idx_usuarios_rol` (`rol`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Administrador','admin@micheladas.local','$2b$12$WBkCMljDjGTkxy.zOdyQGObD8YMtPnc/8uVCPSkrFg5ioYhigisRG','admin',1,'2026-06-04 12:28:42'),(2,'Juan Mesero','mesero@micheladas.local','$2b$12$UhrGnBv4ZSYU5oNDE9cKBu6L5U.BBGo2exYQGV6Ewi0YhGxiC3QuO','mesero',1,'2026-06-04 12:28:42'),(3,'María Barra','cocinero@micheladas.local','$2b$12$qpKYp5qkrTBxk.hv7.ePHu/Fa5rLGsPnCgm5XGME7HdWsXOvAaE8C','cocinero',1,'2026-06-04 12:28:43'),(4,'imanol','josechaverra9010@gmail.com','$2b$12$6f8zeyLgLGZnev5/RmK9..zRLO8uVN34zoxno15i8Wfe6BD3x8SQ.','mesero',1,'2026-06-04 14:14:52');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'michelada'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-14  7:52:29
